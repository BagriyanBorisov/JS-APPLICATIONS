import {showCreateView} from "./createPost.js";

await showCreateView();